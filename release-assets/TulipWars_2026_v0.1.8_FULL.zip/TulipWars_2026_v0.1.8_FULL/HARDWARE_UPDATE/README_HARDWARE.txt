TULIPWARS 2026 v0.1.8 — PHYSICAL TULIP UPDATE

1. Connect the Tulip to Windows with a USB data cable.
2. Close Tulip Web, PuTTY, Arduino IDE, mpremote terminals, and serial monitors.
3. Double-click UPDATE_PHYSICAL_TULIP_v0.1.8.bat.

The batch installs mpremote if necessary, uploads the complete one-file updater,
runs it, preserves local_state.json and ELEMENT115_*.mid files, and launches the
game. If automatic serial detection fails, use the Tulip Web/Desktop upload
method described in README_FIRST.txt instead.
