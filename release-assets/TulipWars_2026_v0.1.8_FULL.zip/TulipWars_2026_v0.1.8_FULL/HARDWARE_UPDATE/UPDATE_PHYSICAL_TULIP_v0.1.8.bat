@echo off
setlocal EnableExtensions
title TulipWars 2026 v0.1.8 Hardware Updater
cd /d "%~dp0"

echo ================================================================
echo   TULIPWARS 2026 v0.1.8 - PHYSICAL TULIP UPDATE
echo ================================================================
echo.
echo Connect the Tulip by USB and close Tulip Web, serial monitors,
echo PuTTY, Arduino IDE, and any other program using the serial port.
echo.

set "PYTHON="
where py >nul 2>&1 && set "PYTHON=py"
if not defined PYTHON where python >nul 2>&1 && set "PYTHON=python"
if not defined PYTHON (
  echo Python was not found. Opening the Python download page.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)

%PYTHON% -m mpremote --help >nul 2>&1
if errorlevel 1 (
  echo Installing mpremote...
  %PYTHON% -m pip install --user mpremote
  if errorlevel 1 (
    echo mpremote could not be installed.
    pause
    exit /b 1
  )
)

echo Uploading the complete installer to the Tulip...
%PYTHON% -m mpremote resume fs cp "INSTALL_OR_UPDATE_TULIPWARS_v0.1.8.py" :INSTALL_OR_UPDATE_TULIPWARS_v0.1.8.py
if errorlevel 1 goto :FAILED

echo Running the update on the Tulip...
%PYTHON% -m mpremote resume exec "exec(open('INSTALL_OR_UPDATE_TULIPWARS_v0.1.8.py').read(), globals())"
if errorlevel 1 goto :FAILED

echo.
echo ================================================================
echo   UPDATE SENT SUCCESSFULLY
 echo ================================================================
echo.
echo The Tulip will install v0.1.8 and launch TulipWars automatically.
echo Its anonymous ship identity and exported MIDI files are preserved.
pause
exit /b 0

:FAILED
echo.
echo The update could not reach the Tulip.
echo Try the other USB port, use a data cable, and close anything using serial.
pause
exit /b 1
