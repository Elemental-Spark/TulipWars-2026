TULIPWARS 2026 v0.1.8 — HARDWARE AUDIO + MIDI DOWNLOAD UPDATE
================================================================

CURRENT STATUS
--------------
v0.1.7 was confirmed working very well in Tulip Web and functional on real
Tulip hardware. v0.1.8 preserves that baseline and fixes the hardware AMY
overload caused by overlapping or excessive Juno voice allocations.

INSTALL OR UPDATE
-----------------
Upload and run:

  UPLOAD_INSTALLER/INSTALL_OR_UPDATE_TULIPWARS_v0.1.8.py

The single file contains the complete game. It safely replaces game code while
preserving local_state.json and every exported ELEMENT115_*.mid file.

WEBSITE/API
-----------
Upload the contents of UPLOAD_TO_WEBSITE over /tulipwars2026/.
Do not delete /tulipwars2026/data/state.json. This package does not include it.
The website download and API health response are synchronized to v0.1.8.

V0.1.8 FIXES
------------
- Maximum six managed Juno voices anywhere in TulipWars.
- Ambient bed uses four voices and reuses them without chord overlap.
- Element115 Tracker fully unloads background ambience on entry.
- Tracker emits at most six simultaneous notes even if all eight rows are on.
- Tracker synth releases before ambience is restored on exit.
- Tulip Web MIDI export automatically downloads the .MID in the browser.
- Tulip hardware/Desktop MIDI export remains saved in the package folder.
- No accounts, logins, passwords, cookies, OAuth, or automatic Tulip World posts.
