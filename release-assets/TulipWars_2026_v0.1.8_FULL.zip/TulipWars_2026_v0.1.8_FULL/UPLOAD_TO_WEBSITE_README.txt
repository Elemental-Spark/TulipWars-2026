TULIPWARS 2026 v0.1.8 WEBSITE/API SYNC

Upload everything inside UPLOAD_TO_WEBSITE over your existing:
  /tulipwars2026/

DO NOT delete:
  /tulipwars2026/data/state.json

This package intentionally contains no state.json, so ordinary overwrite upload
preserves all live ships, chat, cargo, credits, battles, and universe progress.

After upload, check:
  https://elementalspark.com/tulipwars2026/api.php

It should report version 0.1.8 and installer:
  downloads/INSTALL_OR_UPDATE_TULIPWARS_v0.1.8.py
