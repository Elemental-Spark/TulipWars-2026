@echo off
setlocal EnableExtensions
title TulipWars 2026 v0.1.10 Physical Tulip Updater
cd /d "%~dp0"

echo ======================================================================
echo   TULIPWARS 2026 v0.1.10 - PHYSICAL TULIP INSTALL / UPDATE
echo ======================================================================
echo.
echo Tulip must be fully booted normally. DO NOT hold BOOT.
echo Connect the TOP USB/program port with a data-capable cable.
echo Close Tulip Web/Desktop, PuTTY, Arduino, and all serial monitors.
echo This updater does NOT use mpremote raw REPL or firmware flashing.
echo.

if not exist "INSTALL_OR_UPDATE_TULIPWARS_v0.1.10.py" (
  echo ERROR: INSTALL_OR_UPDATE_TULIPWARS_v0.1.10.py is missing beside this batch.
  goto :FAILED
)
if not exist "TULIP_HARDWARE_UPDATER_v0.1.10.py" (
  echo ERROR: TULIP_HARDWARE_UPDATER_v0.1.10.py is missing beside this batch.
  goto :FAILED
)

set "PY_CMD="
where py >nul 2>&1 && set "PY_CMD=py -3"
if not defined PY_CMD where python >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD (
  echo Python 3 was not found. Opening the official download page.
  start "" "https://www.python.org/downloads/windows/"
  goto :FAILED
)

%PY_CMD% -c "import serial" >nul 2>&1
if errorlevel 1 (
  echo Installing the small pyserial connection library...
  %PY_CMD% -m pip install --user pyserial
  if errorlevel 1 goto :FAILED
)

echo Starting automatic Tulip detection and full friendly-REPL transfer...
echo A detailed log will remain in HARDWARE_UPDATE_LOG.txt.
echo.
%PY_CMD% "TULIP_HARDWARE_UPDATER_v0.1.10.py"
if errorlevel 1 goto :FAILED

echo.
echo ======================================================================
echo   UPDATE COMPLETE
echo ======================================================================
echo.
echo The window will remain open until you press a key.
pause
exit /b 0

:FAILED
echo.
echo ======================================================================
echo   UPDATE DID NOT COMPLETE
echo ======================================================================
echo.
echo Review HARDWARE_UPDATE_LOG.txt in this folder.
echo No firmware was flashed and no bootloader mode was used.
echo The window will remain open until you press a key.
pause
exit /b 1
