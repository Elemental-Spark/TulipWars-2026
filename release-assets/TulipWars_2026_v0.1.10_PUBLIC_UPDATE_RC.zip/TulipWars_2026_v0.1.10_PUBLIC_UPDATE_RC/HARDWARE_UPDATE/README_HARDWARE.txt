TULIPWARS 2026 v0.1.10 - PHYSICAL TULIP UPDATE

1. Boot Tulip normally. Do not hold BOOT.
2. Connect the TOP USB/program port with a data-capable cable.
3. Close Tulip Web/Desktop, PuTTY, Arduino, and serial monitors.
4. Double-click UPDATE_PHYSICAL_TULIP_v0.1.10.bat.
5. Leave the window open until UPDATE COMPLETE.

This updater does not use mpremote or raw REPL. It identifies Tulip through the
friendly MicroPython REPL and transfers the full installer in verified chunks.
A detailed HARDWARE_UPDATE_LOG.txt remains beside the batch after every run.

The update preserves local_state.json, Element115 MIDI files, and the existing
tulipwars_user_config.py relay configuration.
