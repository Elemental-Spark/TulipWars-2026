#!/usr/bin/env python3
"""TulipWars 0.1.10 physical Tulip updater using friendly REPL and pyserial."""
from __future__ import print_function
import os
import re
import sys
import time
import traceback

VERSION = '0.1.10'
INSTALLER_NAME = 'INSTALL_OR_UPDATE_TULIPWARS_v0.1.10.py'
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOCAL_INSTALLER = os.path.join(BASE_DIR, INSTALLER_NAME)
REMOTE_INSTALLER = '/user/' + INSTALLER_NAME
LOG_PATH = os.path.join(BASE_DIR, 'HARDWARE_UPDATE_LOG.txt')
BAUD = 115200
PROMPT = b'>>> '
MARKER = 'TULIPWARS_PORT_OK'
CHUNK_BYTES = 256


def log(message=''):
    text = str(message)
    print(text, flush=True)
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as handle:
            handle.write(text + '\n')
    except Exception:
        pass


def reset_log():
    try:
        with open(LOG_PATH, 'w', encoding='utf-8') as handle:
            handle.write('TulipWars 2026 v%s hardware update log\n' % VERSION)
            handle.write('Started: %s\n\n' % time.ctime())
    except Exception:
        pass


def candidate_ports():
    from serial.tools import list_ports
    ports = list(list_ports.comports())
    def score(port):
        text = ('%s %s %s' % (port.description, port.manufacturer, port.hwid)).upper()
        points = 0
        for token, value in (
            ('TULIP', 200), ('CH340', 100), ('USB-SERIAL', 80),
            ('USB SERIAL', 70), ('CP210', 50), ('UART', 30)
        ):
            if token in text:
                points += value
        return (-points, str(port.device))
    return sorted(ports, key=score)


def read_available(ser, duration=0.25):
    end = time.time() + duration
    data = bytearray()
    while time.time() < end:
        waiting = getattr(ser, 'in_waiting', 0)
        if waiting:
            data.extend(ser.read(waiting))
            end = time.time() + 0.08
        else:
            time.sleep(0.015)
    return bytes(data)


def wait_for_prompt(ser, timeout=5.0, initial=b''):
    end = time.time() + timeout
    data = bytearray(initial)
    while time.time() < end:
        waiting = getattr(ser, 'in_waiting', 0)
        if waiting:
            data.extend(ser.read(waiting))
            if PROMPT in data or data.rstrip().endswith(b'>>>'):
                return bytes(data), True
        else:
            time.sleep(0.015)
    return bytes(data), False


def wake_friendly_repl(ser):
    try:
        ser.reset_input_buffer()
    except Exception:
        pass
    # Cancel unfinished input/running Python, force friendly REPL, then request a prompt.
    for _ in range(6):
        ser.write(b'\x03')
        ser.flush()
        time.sleep(0.08)
    ser.write(b'\x02\r\n\r\n')
    ser.flush()
    # Drain all prompts produced by the interrupt sequence so the next command
    # cannot be mistaken for stale output.
    time.sleep(0.45)
    data = read_available(ser, duration=0.65)
    ok = PROMPT in data or data.rstrip().endswith(b'>>>')
    try:
        ser.reset_input_buffer()
    except Exception:
        pass
    return data, ok


def send_command(ser, command, timeout=8.0, require_prompt=True):
    # Every command is one physical line, so continuation-mode cannot be entered.
    try:
        ser.reset_input_buffer()
    except Exception:
        pass
    ser.write(command.encode('utf-8') + b'\r\n')
    ser.flush()
    data, ok = wait_for_prompt(ser, timeout=timeout)
    text = data.decode('utf-8', 'replace')
    if 'Traceback (most recent call last)' in text:
        raise RuntimeError('Tulip command failed:\n' + text[-1800:])
    if require_prompt and not ok:
        raise RuntimeError('Tulip did not return to the REPL prompt. Last response:\n' + text[-1200:])
    return text


def identify_port(port_info):
    import serial
    port = str(port_info.device)
    log('  Checking %s - %s' % (port, port_info.description))
    try:
        with serial.Serial(port, BAUD, timeout=0.08, write_timeout=2.0) as ser:
            try:
                ser.dtr = False
                ser.rts = False
            except Exception:
                pass
            transcript, ok = wake_friendly_repl(ser)
            if not ok:
                log('    No friendly REPL prompt received.')
                return False
            response = send_command(
                ser,
                "import tulip;print('%s|' + str(tulip.board()))" % MARKER,
                timeout=6.0,
            )
            if MARKER in response:
                board = response.split(MARKER + '|', 1)[1].splitlines()[0].strip()
                log('    Tulip confirmed: %s on %s' % (board, port))
                return True
            log('    Serial device responded, but it was not a Tulip.')
    except Exception as exc:
        log('    Could not use %s: %s' % (port, exc))
    return False


def find_tulip_port():
    ports = candidate_ports()
    if not ports:
        raise RuntimeError("No Windows serial ports were found. Use Tulip's TOP USB/program port and a data cable.")
    log('Checking %d serial device(s)...' % len(ports))
    for port_info in ports:
        if identify_port(port_info):
            return str(port_info.device)
    raise RuntimeError(
        'A Tulip REPL was not found. Press Tulip RESET once, wait for normal boot, '
        'close every serial program, and run the batch again. Do not hold BOOT.'
    )


def upload_installer(port):
    import serial
    payload = open(LOCAL_INSTALLER, 'rb').read()
    total = len(payload)
    log('Installer size: %d bytes' % total)
    with serial.Serial(port, BAUD, timeout=0.08, write_timeout=3.0) as ser:
        try:
            ser.dtr = False
            ser.rts = False
        except Exception:
            pass
        _, ok = wake_friendly_repl(ser)
        if not ok:
            raise RuntimeError('The confirmed Tulip stopped responding before transfer.')
        quoted = repr(REMOTE_INSTALLER)
        send_command(
            ser,
            "import os;_p=%s;_n=_p.rsplit('/',1)[1];os.remove(_p) if _n in os.listdir('/user') else None" % quoted,
        )
        sent = 0
        last_percent = -1
        for offset in range(0, total, CHUNK_BYTES):
            chunk = payload[offset:offset + CHUNK_BYTES]
            command = (
                "import ubinascii as _b;_f=open(%s,'ab');"
                "_f.write(_b.unhexlify('%s'));_f.close()"
            ) % (quoted, chunk.hex())
            send_command(ser, command, timeout=10.0)
            sent += len(chunk)
            percent = int((sent * 100) / total)
            if percent >= last_percent + 5 or sent == total:
                last_percent = percent
                log('Uploading: %3d%% (%d/%d bytes)' % (percent, sent, total))
        response = send_command(ser, "import os;print('TULIPWARS_UPLOAD_SIZE',os.stat(%s)[6])" % quoted)
        match = re.search(r'TULIPWARS_UPLOAD_SIZE\s+(\d+)', response)
        if not match or int(match.group(1)) != total:
            raise RuntimeError('Upload-size verification failed. Tulip response:\n' + response[-1000:])
        log('Upload verified. Running the complete installer...')
        response = send_command(ser, "exec(open(%s).read(),globals())" % quoted, timeout=75.0)
        # Deferred app launch may print after the friendly prompt returns.
        response += read_available(ser, duration=2.0).decode('utf-8', 'replace')
        for line in response.splitlines():
            if ('Installed ' in line or 'Full package installed at:' in line or
                    'Starting TulipWars' in line or 'START FAILED' in line or
                    'Traceback' in line or 'NameError' in line):
                log('TULIP: ' + line)
        if 'Traceback (most recent call last)' in response or 'START FAILED:' in response:
            raise RuntimeError('Installer reported a startup failure. See HARDWARE_UPDATE_LOG.txt.')
        if 'Full package installed at:' not in response:
            raise RuntimeError('The installer did not report a completed package write. See the log.')
        return response


def main():
    reset_log()
    log('=' * 70)
    log('TULIPWARS 2026 v%s PHYSICAL TULIP INSTALL / UPDATE' % VERSION)
    log('Friendly-REPL transfer: no mpremote and no bootloader mode')
    log('=' * 70)
    if not os.path.isfile(LOCAL_INSTALLER):
        raise RuntimeError('Missing installer beside updater: ' + LOCAL_INSTALLER)
    port = find_tulip_port()
    log('Using confirmed Tulip port: ' + port)
    upload_installer(port)
    log('')
    log('=' * 70)
    log('UPDATE COMPLETE - TULIPWARS 2026 v%s' % VERSION)
    log('The full package was written and its installer completed successfully.')
    log('=' * 70)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        reset = False
        log('')
        log('UPDATE FAILED: %s' % exc)
        log('')
        log('Nothing was flashed and bootloader mode was never used.')
        log('Press Tulip RESET once, wait for normal boot, then retry.')
        log('Close Tulip Web/Desktop, PuTTY, Arduino, and serial monitors first.')
        try:
            with open(LOG_PATH, 'a', encoding='utf-8') as handle:
                traceback.print_exc(file=handle)
        except Exception:
            pass
        raise SystemExit(1)
