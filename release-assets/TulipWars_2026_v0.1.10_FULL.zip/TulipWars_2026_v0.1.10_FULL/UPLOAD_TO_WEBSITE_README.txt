Upload the CONTENTS of UPLOAD_TO_WEBSITE over /tulipwars2026/.
Do not delete /tulipwars2026/data/state.json.
This release contains no state.json and therefore preserves the live universe.
The synchronized installer is downloads/INSTALL_OR_UPDATE_TULIPWARS_v0.1.10.py.
