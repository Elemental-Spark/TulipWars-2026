TULIPWARS 2026 v0.1.10 - COMPLETE RELEASE CANDIDATE

This is a full replacement package, not a loose patch.

PRIMARY FIXES
- Fixes the installer NameError: _user_dir is now defined and tested.
- Replaces the accidentally malformed one-line hardware helper.
- Replaces mpremote/raw-REPL transfer with a friendly-REPL pyserial uploader.
- Leaves HARDWARE_UPDATE_LOG.txt after every physical attempt.

PRESERVED
- v0.1.9 old-terminal touch keypad and touchable numbered choices.
- Full A-Z/0-9 touch chat input and tracker controls.
- Six total Juno voice cap, four-voice ambience, and tracker-exclusive audio.
- Browser .MID download and local hardware MIDI saving.
- Anonymous no-login PHP universe and no automatic Tulip World posts.

TEST THE PHYSICAL UPDATER ON YOUR TULIP BEFORE PUBLICLY PROMOTING THIS BUILD.
