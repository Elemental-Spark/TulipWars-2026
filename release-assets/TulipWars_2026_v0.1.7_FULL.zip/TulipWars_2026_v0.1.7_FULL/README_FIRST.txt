TULIPWARS 2026 v0.1.7 FULL CLEAN PACKAGE
==========================================

TEST ON TULIP WEB FIRST — DO NOT COPY TO HARDWARE YET
1. Close and reopen the Tulip Web tab, or refresh it, to reset the running app.
2. Show the code editor.
3. Upload UPLOAD_TO_TULIP_WEB/INSTALL_TULIPWARS_WEB_v0.1.7.py
4. Select it, load it into the editor, and click the green Run button.

The installer is the entire game. It cleans all obsolete package code and old
installer/TAR files from Tulip Web's /user area, preserves local_state.json and
ELEMENT115_*.mid exports, installs the current build, and starts it.

WEBSITE
The existing v0.1.6 website/API can remain for this test. The complete v0.1.7
website is included if you prefer to update it. Never delete data/state.json.

PUBLIC-SERVER CLEANUP
Once v0.1.7 works, obsolete files that may be deleted from your web host are:
  /tulipwars2026/download.php
  /tulipwars2026/tulipwars_files.php
  /tulipwars2026/downloads/tulipwars2026.tar
The included .htaccess already denies the first two endpoints and old TAR files.
