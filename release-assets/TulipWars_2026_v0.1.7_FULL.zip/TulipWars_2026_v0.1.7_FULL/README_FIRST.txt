TULIPWARS 2026 v0.1.7 — FULL RELEASE, WEBSITE/API SYNCHRONIZED
================================================================

The v0.1.7 Tulip Web build is the current confirmed-working baseline.

TULIP WEB
Upload UPLOAD_TO_TULIP_WEB/INSTALL_TULIPWARS_WEB_v0.1.7.py in the Tulip Web
code editor and Run it. The one file installs the complete game.

WEBSITE/API
Upload every file inside UPLOAD_TO_WEBSITE/ over /tulipwars2026/.
NEVER delete or overwrite /tulipwars2026/data/state.json. This package does not
contain state.json, so the live anonymous universe is preserved automatically.

There is no login API, no account system, and no automatic Tulip World posting.
