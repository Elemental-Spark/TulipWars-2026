# 🌷🚀 TulipWars 2026 v0.1.7 — Public Tulip Web Test

Explore space, trade commodities, scan mysterious signals, battle aliens, meet other anonymous captains at stations, and create procedural music from your ship console.

## Features
- Anonymous play — no accounts, passwords, email, OAuth, or login API
- Nine explorable star systems with fuel, danger, encounters, cargo, hull, and shields
- Dynamic station markets and persistent trading
- Turn-based alien combat, salvage, rewards, and emergency retreats
- Anonymous station-local BBS chat and docked-player presence
- 100% AMY-synthesized sound with randomized Juno-style space ambience
- Element115 Tracker: 8×16 sequencer, AMY playback, MIDI output, and `.mid` export
- Read-only Tulip World lounge — TulipWars never posts automatically

## Install — no typing or pasting
1. Download and extract the attached ZIP.
2. Open `https://tulip.computer/run/`.
3. Click **Show code editor**.
4. Upload `INSTALL_TULIPWARS_WEB_v0.1.7.py` with the blue Upload button.
5. Select it, click the red load arrow, then click the green Run button.
6. The complete game installs and starts automatically.

This is the Tulip Web public test build. Please hold off on physical Tulip CC hardware installation until the Web build is confirmed stable.

The installer cleans old TulipWars code from local Tulip Web storage while preserving anonymous ship saves and exported Element115 MIDI files.
