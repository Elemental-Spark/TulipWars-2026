Upload everything inside UPLOAD_OVER_EXISTING_TULIPWARS2026 over:
/tulipwars2026/

DO NOT delete /tulipwars2026/data/state.json.
This package contains no state.json and preserves the live universe.

The synchronized installer is:
downloads/INSTALL_OR_UPDATE_TULIPWARS_v0.1.10.py

Confirm the physical hardware test before publishing this sync.
